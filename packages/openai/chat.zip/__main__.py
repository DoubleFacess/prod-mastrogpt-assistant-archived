#--web true
#--kind python:default

from chat import chat

def main(args):
    return chat(args)
