#--web true
#--kind python:default

from widget import widget

def main(args):
    return widget(args)
